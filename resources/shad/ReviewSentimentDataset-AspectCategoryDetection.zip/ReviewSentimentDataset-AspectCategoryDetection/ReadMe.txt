##################
##	Readme.txt	##
##################

This dataset is freely available for the research purpose only. 

This folder contains user review sentiment dataset for Aspect Category Detection and its Sentiment Classification. 
The dataset is in xml fomrat. Please read following paper for the annotation format and other details. 
If you find this helpful and use it in your research please cite the paper.

---------------------------------------------------

Md Shad Akhtar, Asif Ekbal, Pushpak Bhattacharyya; Aspect Based Sentiment Analysis: Category Detection and Sentiment Classification for Hindi; In proceedings of the 17th International Conference on Intelligent Text Processing and Computational Linguistics (CICLING 2016); Konya, Turkey; 2016. 
