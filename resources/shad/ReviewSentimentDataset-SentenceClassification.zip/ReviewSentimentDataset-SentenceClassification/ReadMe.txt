##################
##	Readme.txt	##
##################

This dataset is freely available for the research purpose only. 


This folder contains review sentiment dataset for sentence level sentiment classification. 

The dataset is in xml fomrat. Please read following paper for the annotation format and other details. 
If you find this helpful and use it in your research please cite the paper.

---------------------------------------------------

Md Shad Akhtar, Ayush Kumar, Asif Ekbal, Pushpak Bhattacharyya; A Hybrid Deep Learning Architecture for Sentiment Analysis; In proceedings of the 26th International Conference on Computational Linguistics (COLING 2016); 482–493; Osaka, Japan; 2016. 
