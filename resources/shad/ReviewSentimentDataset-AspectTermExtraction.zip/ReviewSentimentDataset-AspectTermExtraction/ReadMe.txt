##################
##	Readme.txt	##
##################

This dataset is freely available for the research purpose only. 


This folder contains user review sentiment dataset for Aspect Term Extraction and its Sentiment Classification. 

The dataset is in xml fomrat. Please read following paper for the annotation format and other details. 
If you find this helpful and use it in your research please cite the paper.

---------------------------------------------------

Md Shad Akhtar, Asif Ekbal, Pushpak Bhattacharyya; Aspect Based Sentiment Analysis in Hindi: Resource Creation and Evaluation; In proceedings of the 10th International Conference on Language Resource and Evaluation (LREC 2016); 23-28; Portorož, Slovenia; 2016. 
