To train the model use run.sh --> it will save the model in logs_original folder.

Filter misclassified samples using misclassified.py

To mitigate the bias due to one entity run: unlearn_single.sh 
It will save the unlearned model in "weights_shap" folder.

