Requirements:
Python 3
pytorch
transformers
sklearn
pandas
re
tqdm
argparse

############################################################################################################
mBERT based sentiment classification for given aspect

To run the code for laptop domain (for setup 2)
sh run_multi_lap3.sh

for setup 2 of laptop domain (setup 1)
sh run_multi_lap4.sh

NOTE:: same code will run for restaurant domain (need to change only change data path in sh and python file)


#############################################################################################################

Aspect extraction task (present in folder ATE_task)
run the following command
sh seq.sh




