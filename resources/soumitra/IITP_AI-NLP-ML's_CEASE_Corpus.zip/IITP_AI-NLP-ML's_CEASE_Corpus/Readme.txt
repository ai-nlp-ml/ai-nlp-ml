The dataset is present in the 'data' folder which contains 15  different '.txt' files, one for each emotion class: 

Emotion Classes considered are: Abuse, Anger, Blame, Fear, Forgiveness, Guilt, Hopefulness, Hopelessness, Happiness_Peacefulness, Information, Instruction, Love, Pride, Sorrow, Thankfulness

Each file contains pre-processed sentences from real-life suicide notes.

#################################################################################

~~~ The full corpus contains 2393 annotated instances from 15 emotion classes ~~~

#################################################################################

License:
This dataset is distributed under the CC-BY-NC license

Citing the paper:
Please cite our paper if you use the dataset in your research work.

@InProceedings{ghosh-ekbal-bhattacharyya:2020:LREC,
  author    = {Ghosh, Soumitra  and  Ekbal, Asif  and  Bhattacharyya, Pushpak},
  title     = {CEASE, a Corpus of Emotion Annotated Suicide notes in English},
  booktitle      = {Proceedings of The 12th Language Resources and Evaluation Conference},
  month          = {May},
  year           = {2020},
  address        = {Marseille, France},
  publisher      = {European Language Resources Association},
  pages     = {1611--1619},
  abstract  = {A suicide note is usually written shortly before the suicide and it provides a chance to comprehend the self-destructive state of mind of the deceased. From a psychological point of view, suicide notes have been utilized for recognizing the motive behind the suicide. To the best of our knowledge, there is no openly accessible suicide note corpus at present, making it challenging for the researchers and developers to deep dive into the area of mental health assessment and suicide prevention. In this paper, we create a fine-grained emotion annotated corpus (CEASE) of suicide notes in English and develop various deep learning models to perform emotion detection on the curated dataset. The corpus consists of 2393 sentences from around 205 suicide notes collected from various sources. Each sentence is annotated with a particular emotion class from a set of 15 fine-grained emotion labels, namely (forgiveness, happiness\_peacefulness, love, pride, hopefulness, thankfulness, blame, anger, fear, abuse, sorrow, hopelessness, guilt, information, instructions). For the evaluation, we develop an ensemble architecture, where the base models correspond to three supervised deep learning models, namely Convolutional Neural Network (CNN), Gated Recurrent Unit (GRU) and Long Short Term Memory (LSTM). We obtain the highest test accuracy of 60.17\% and cross-validation accuracy of 60.32\%},
  url       = {https://www.aclweb.org/anthology/2020.lrec-1.200}
}

